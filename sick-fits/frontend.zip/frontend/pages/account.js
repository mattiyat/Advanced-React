export default function AccountPage() {
  return (
    <div>
      <p>This is from the account page</p>
    </div>
  );
}
