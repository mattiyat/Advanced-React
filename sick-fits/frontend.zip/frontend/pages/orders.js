export default function OrderPage() {
  return (
    <div>
      <p>orders page</p>
    </div>
  );
}
