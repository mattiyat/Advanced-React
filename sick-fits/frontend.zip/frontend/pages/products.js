import Products from '../components/Products';

export default function ProductsPage() {
  return <Products />;
}
