import Page from '../components/Page';

export default function IndexPage() {
  return <div>This is the index page</div>;
}
