import Page from '../components/Page';

export default function SellPage() {
  return <p>hey i am sell Page</p>;
}
