import '@testing-library/jest-dom';

window.alert = console.log;
